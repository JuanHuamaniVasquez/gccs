package pe.edu.ulasalle.demospringdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemospringdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemospringdbApplication.class, args);
	}

}